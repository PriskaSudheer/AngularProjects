import{ Component } from '@angular/core';
import { Server } from 'selenium-webdriver/safari';


@Component({
    selector:'app-server',
    templateUrl:'./Server.component.html'
})
export class ServerComponent{


}